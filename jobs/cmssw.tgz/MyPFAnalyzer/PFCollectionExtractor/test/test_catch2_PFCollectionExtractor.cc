#include "catch.hpp"
#include "FWCore/TestProcessor/interface/TestProcessor.h"
#include "FWCore/Utilities/interface/Exception.h"

static constexpr auto s_tag = "[PFCollectionExtractor]";

TEST_CASE("Standard checks of PFCollectionExtractor", s_tag) {
  const std::string baseConfig{
      R"_(from FWCore.TestProcessor.TestProcess import *
process = TestProcess()
# Configure the plugin as its actual EDAnalyzer type and exercise the data-safe path.
process.toTest = cms.EDAnalyzer("PFCollectionExtractor", isMC = cms.bool(False))
# TFileService is required because the analyzer books its output tree at construction.
process.TFileService = cms.Service("TFileService", fileName = cms.string("test_pf_extractor.root"))
process.moduleToTest(process.toTest)
)_"};

  edm::test::TestProcessor::Config config{baseConfig};
  SECTION("base configuration is OK") { REQUIRE_NOTHROW(edm::test::TestProcessor(config)); }

  SECTION("No event data") {
    edm::test::TestProcessor tester(config);

    REQUIRE_THROWS_AS(tester.test(), cms::Exception);
    //If the module does not throw when given no data, substitute
    //REQUIRE_NOTHROW for REQUIRE_THROWS_AS
  }

  SECTION("beginJob and endJob only") {
    edm::test::TestProcessor tester(config);

    REQUIRE_NOTHROW(tester.testBeginAndEndJobOnly());
  }

  SECTION("Run with no LuminosityBlocks") {
    edm::test::TestProcessor tester(config);

    REQUIRE_NOTHROW(tester.testRunWithNoLuminosityBlocks());
  }

  SECTION("LuminosityBlock with no Events") {
    edm::test::TestProcessor tester(config);

    REQUIRE_NOTHROW(tester.testLuminosityBlockWithNoEvents());
  }
}

//Add additional TEST_CASEs to exercise the modules capabilities
